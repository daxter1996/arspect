<?php $__env->startSection('content'); ?>

    <div class="row" style="margin-top: 10px">
        <div class="col s12 ">
            <div class="input-field col s12">
                <i class="material-icons prefix">search</i>
                <input id="buscarBtn" type="text" class="validate">
                <label for="buscarBtn">Artista/Galeria</label>
            </div>
        </div>
        <div class="col s12 m4">
            <h5 class="">Destacados</h5>
            <?php for($i=0;$i<3;$i++): ?>

                    <div class="col s12 ">
                        <div class="card horizontal">
                            <div class="card-image">
                                <img height="100" width="100" src="http://www.ikea.com/es/es/images/products/pjatteryd-cuadro__0455534_PE603586_S4.JPG">
                            </div>
                            <div class="card-stacked">
                                <div class="card-content">
                                    <p><strong>Nombre</strong></p>
                                    <p><strong>Tags</<strong></p>
                                </div>
                                <div class="card-action">
                                    <a href="#">Ver Perfil</a>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php endfor; ?>
        </div>
        <div class="col s12 m8">
            <h5>Resultados</h5>
            <div id="results">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <a href="<?php echo e(url('/perfil/' . $user->id)); ?>"  class=" col s12 z-depth-1 black-text">
                            <div class="col s12" style="padding: 10px">
                                <p><strong><?php echo e($user->name . " " . $user->surname); ?></strong></p>
                                <strong>Tags</strong>
                                <?php $__currentLoopData = $user->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="chip"><?php echo e($tag->type); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.slider').slider();
        });
        
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $('#buscarBtn').keyup(function () {
                $.ajax({
                    url: "<?php echo e(url('/buscar')); ?>",
                    type: "POST",
                    data: JSON.stringify({ name : $(this).val() }),
                    contentType: "application/json; charset=utf-8",
                    cache: false,
                    processData: false,
                    success: function (data) {
                        $("#results").empty();
                        $("#results").html(data);
                    }, error: function () {
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>