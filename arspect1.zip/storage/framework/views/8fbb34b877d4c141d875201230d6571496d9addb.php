<?php $__env->startSection('content'); ?>
    <div id="caixa" class="row">
        <?php if(!Auth::guest()): ?>
            <div class="col-sm-3"><strong>Nom: </strong> <?php echo e(Auth::user()->name . " " . Auth::user()->surname); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>