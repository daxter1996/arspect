<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <a href="<?php echo e(url('/perfil/' . $user->id)); ?>"  class=" col s12 z-depth-1 black-text">
            <div class="col s12" style="padding: 10px">
                <p><strong><?php echo e($user->name . " " . $user->surname); ?></strong></p>
                <strong>Tags</strong>
                <?php $__currentLoopData = $user->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="chip"><?php echo e($tag->type); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>