<?php $__env->startSection('nav'); ?>
    <nav class="navbar navbar-default ">
        <div class="container">
            <div class="navbar-header">
                <a href="<?php echo e(url('/')); ?>" class="navbar-brand"> Arspect </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobileDrop">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="mobileDrop">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(url('/login')); ?>" class="navbar-right"> Login </a></li>
                    <li><a href="<?php echo e(url('/register')); ?>" class="navbar-right"> Register </a></li>
                    <li><a href="<?php echo e(url('/about')); ?>" class="navbar-right"> Sobre Nosotros </a></li>
                </ul>
            </div>
        </div>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="caixa" class="row" style="margin-top: 50px">
        <div class="col-sm-3">
        </div>
        <div class="col-sm-6" style="margin: 10px">
            <h1 style="text-align: center;">Registrarse como visitante</h1>
            <hr/>
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register/register')); ?>">
                <div class="form-group">
                    <label for="email">Nombre</label>
                    <input type="text" class="form-control" id="email">
                </div>
                <div class="form-group">
                    <label for="pwd">Apellidos</label>
                    <input type="text" class="form-control" id="pwd">
                </div>
                <div class="form-group">
                    <label for="pwd">Email</label>
                    <input type="email" class="form-control" id="pwd">
                </div>
                <div class="form-group">
                    <label for="pwd">Contraseña</label>
                    <input type="password" class="form-control" id="pwd">
                </div>
                <div class="form-group">
                    <label for="pwd">Confirmar contraseña</label>
                    <input type="password" class="form-control" id="pwd">
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>